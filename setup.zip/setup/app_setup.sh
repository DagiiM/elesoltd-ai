#!/bin/bash

# Set domain name
domain=eleso.ltd

# Set MySQL password
mysql_password=DagiiZ.12

# Set Django application repository URL
repo_url=https://github.com/user/django-project.git

# Set Django application system user and group
system_user=elesoltd
system_group=elesoltd

# Set Django application MySQL user and database
mysql_user=elesoltd
mysql_database=elesoltd

# Set Django application email address
email=support@eleso.ltd

# Update package index and upgrade installed packages
apt-get update
apt-get upgrade -y

# Install necessary packages
apt-get install python3 python3-pip mysql-server apache2 libapache2-mod-wsgi-py3 -y

# Create system user and group for Django application
adduser --system --group $system_user

# Create MySQL user and database for Django application
mysql -u root -p$mysql_password << EOF
CREATE DATABASE $mysql_database;
CREATE USER '$mysql_user'@'localhost' IDENTIFIED BY '$mysql_password';
GRANT ALL PRIVILEGES ON $mysql_database.* TO '$mysql_user'@'localhost';
FLUSH PRIVILEGES;
EOF

# Clone Django application repository and install requirements
su - $system_user -c "git clone $repo_url /home/$system_user/$mysql_database"
su - $system_user -c "pip3 install -r /home/$system_user/$mysql_database/requirements.txt"

# Set correct permissions for Django application directory
chown -R $system_user:$system_group /home/$system_user

# Create Apache configuration file for Django application
cat > /etc/apache2/sites-available/django.conf << EOF
<VirtualHost *:80>
    ServerName $domain
    ServerAdmin $email

    WSGIDaemonProcess $system_user python-path=/home/$system_user/$mysql_database:/home/$system_user/.local/lib/python3.9/site-packages
    WSGIProcessGroup $system_user
    WSGIScriptAlias / /home/$system_user/$mysql_database/django_project/wsgi.py

    <Directory /home/$system_user/$mysql_database/django_project>
        <Files wsgi.py>
            Require all granted
        </Files>
    </Directory>

    Alias /static /home/$system_user/$mysql_database/static
    <Directory /home/$system_user/$mysql_database/static>
        Require all granted
    </Directory>

    ErrorLog \${APACHE_LOG_DIR}/error.log
    CustomLog \${APACHE_LOG_DIR}/access.log combined
</VirtualHost>
EOF

# Enable the Apache configuration and restart Apache
a2ensite django
systemctl restart apache2

# Set MySQL password in Django application settings
sed -i "s/MYSQL_PASSWORD/$mysql_password/g" /home/$system_user/$mysql_database/django_project/settings.py

# Run Django database migrations
su - $system_user -c "python3 /home/$system_user/$mysql_database/manage.py migrate"

# Create Django superuser
echo "from django.contrib.auth import get_user_model; User = get_user_model(); User.objects.create_superuser('admin', '$email', '$mysql_password')" | su - $system_user -c "python3 /home/$system_user/$mysql_database/manage.py shell"

# Collect static files
su - $system_user -c "python3 /home/$system_user/$mysql_database/manage.py collectstatic --noinput"

# Restart Apache to apply changes
systemctl restart apache2


