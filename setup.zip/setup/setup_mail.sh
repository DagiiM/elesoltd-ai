#!/bin/bash

# Set domain name
domain=eleso.ltd

# Set server IP address
ip=139.144.183.72

# Set email addresses
support_email=support@eleso.ltd
info_email=info@eleso.ltd
douglasmutethia_email=douglasmutethia@eleso.ltd

# Function to install and configure Postfix
install_and_configure_postfix() {
  # Install Postfix
  apt-get update
  apt-get install -y postfix

  # Set hostname and domain in Postfix configuration
  postconf -e "myhostname = mail.$domain"
  postconf -e "mydomain = $domain"
  postconf -e "myorigin = $domain"

  # Set IP address in Postfix configuration
  postconf -e "inet_interfaces = all"
  postconf -e "inet_protocols = all"

  # Set DNS records for domain
  echo "$ip $domain" >> /etc/hosts

  # Set MX record for domain
  echo "$domain MX 10 $domain" >> /etc/postfix/main.cf

  # Set SPF record for domain
  echo "v=spf1 a mx ip4:$ip ~all" >> /etc/postfix/main.cf
}


# Function to install and configure OpenDKIM
install_and_configure_opendkim() {
  # Install opendkim and tools
  apt-get install -y opendkim opendkim-tools

  # Set DKIM record for domain
  opendkim-genkey -D /etc/opendkim/keys/$domain/ -d $domain -s default
  echo "default._domainkey.$domain $domain:default:/etc/opendkim/keys/$domain/default.private" >> /etc/opendkim/KeyTable
  echo "*@$domain default._domainkey.$domain" >> /etc/opendkim/SigningTable
  echo "default._domainkey.$domain IN TXT ( v=DKIM1; k=rsa; p=MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDZsfv1qscqYdy4vY+P4e3cAtmv" >> /etc/opendkim/TrustedHosts
  echo "^%.$domain $domain" >> /etc/opendkim/TrustedHosts

  # Configure opendkim to use DKIM key pair
  echo "Domain                  eleso.ltd" >> /etc/opendkim.conf
  echo "KeyFile                 /etc/opendkim/keys/mail.private" >> /etc/opendkim.conf
  echo "Selector                mail" >> /etc/opendkim.conf

  # Configure Postfix to use opendkim for signing emails
  echo "milter_protocol = 2" >> /etc/postfix/main.cf
  echo "milter_default_action = accept" >> /etc/postfix/main.cf
  echo "smtpd_milters = inet:localhost:8891" >> /etc/postfix/main.cf
  echo "non_smtpd_milters = inet:localhost:8891" >> /etc/postfix/main.cf
}

# Function to install and configure TLS
install_and_configure_tls() {
  # Install openssl
  apt-get install -y openssl

  # Generate self-signed TLS certificate and private key
  openssl req -x509 -nodes -days 365 -newkey rsa:2048 -keyout tls_private_key.pem -out tls_certificate.pem -subj "/CN=$domain"

  # Copy TLS certificate and private key to appropriate locations
  cp tls_certificate.pem /etc/ssl/certs/
  cp tls_private_key.pem /etc/ssl/private/

  # Configure Postfix to use TLS certificate and private key
  postconf -e "smtpd_tls_security_level = may"
  postconf -e "smtpd_tls_cert_file = /etc/ssl/certs/tls_certificate.pem"
  postconf -e "smtpd_tls_key_file = /etc/ssl/private/tls_private_key.pem"
}

# Function to install and configure spam and virus filtering
install_and_configure_spam_filtering() {
  # Install spamassassin
  apt-get install -y spamassassin

  # Configure spamassassin to use Bayesian filtering
  sed -i "s/ENABLED=0/ENABLED=1/g" /etc/default/spamassassin
  sed -i "s/bayes_auto_learn = 0/bayes_auto_learn = 1/g" /etc/spamassassin/local.cf
  sa-learn --sync
  service spamassassin start

  # Configure Postfix to use spamassassin
  postconf -e "content_filter = smtp-spamassassin"
  echo "spamassassin unix - n n - - pipe user=spamassassin argv=/usr/bin/spamc -f -e /usr/sbin/sendmail -oi -f ${sender} ${recipient}" >> /etc/postfix/main.cf
}

# Set domain name
domain=eleso.ltd

# Set server IP address
ip=139.144.183.72

# Install Postfix
apt-get update
apt-get install postfix

# Set hostname and domain in Postfix configuration
postconf -e "myhostname = mail.$domain"
postconf -e "mydomain = $domain"
postconf -e "myorigin = $domain"

# Set IP address in Postfix configuration
postconf -e "inet_interfaces = all"
postconf -e "inet_protocols = all"

# Set DNS records for domain
echo "$ip $domain" >> /etc/hosts

# Set MX record for domain
echo "$domain MX 10 $domain" >> /etc/postfix/main.cf

# Set SPF record for domain
echo "v=spf1 a mx ip4:$ip ~all" >> /etc/postfix/main.cf

# Install and configure OpenDKIM
install_and_configure_opendkim

# Install and configure TLS
install_and_configure_tls

# Create email addresses
postfix add-alias support@eleso.ltd support@eleso.ltd
postfix add-alias info@eleso.ltd info@eleso.ltd
postfix add-alias douglasmutethia@eleso.ltd douglasmutethia@eleso.ltd

# Install and configure spam and virus filtering
install_and_configure_spam_filtering